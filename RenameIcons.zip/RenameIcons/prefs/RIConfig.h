#import <Foundation/Foundation.h>

NSString *RIBaseDir(void);
NSMutableDictionary *RILoadConfig(void);
BOOL RISaveConfig(NSDictionary *cfg);
