#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>

@interface RIAppController : PSListController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>
@end
