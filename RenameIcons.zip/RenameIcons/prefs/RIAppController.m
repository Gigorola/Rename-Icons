#import "RIAppController.h"
#import "RIConfig.h"

static UIImage *RISquareIcon(UIImage *img, CGFloat side) {
    CGFloat s = MIN(img.size.width, img.size.height);
    CGFloat k = side / s;
    CGFloat ox = (img.size.width - s) / 2.0;
    CGFloat oy = (img.size.height - s) / 2.0;
    UIGraphicsImageRendererFormat *fmt = [UIGraphicsImageRendererFormat defaultFormat];
    fmt.scale = 1;
    UIGraphicsImageRenderer *r = [[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(side, side) format:fmt];
    return [r imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        [img drawInRect:CGRectMake(-ox * k, -oy * k, img.size.width * k, img.size.height * k)];
    }];
}

@implementation RIAppController

- (NSString *)bundleID {
    return [self.specifier propertyForKey:@"bundleID"];
}

- (NSArray *)specifiers {
    if (!_specifiers) {
        NSMutableArray *specs = [NSMutableArray array];
        self.title = self.specifier.name;

        PSSpecifier *g1 = [PSSpecifier groupSpecifierWithName:@"Название"];
        [g1 setProperty:@"Оставь пустым, чтобы показывать оригинальное название." forKey:@"footerText"];
        [specs addObject:g1];

        PSSpecifier *nameSpec = [PSSpecifier preferenceSpecifierNamed:@"Название"
                                                               target:self
                                                                  set:@selector(setName:specifier:)
                                                                  get:@selector(currentName:)
                                                               detail:nil
                                                                 cell:PSEditTextCell
                                                                 edit:nil];
        [nameSpec setProperty:@"Оригинальное название" forKey:@"placeholder"];
        [specs addObject:nameSpec];

        PSSpecifier *g2 = [PSSpecifier groupSpecifierWithName:@"Иконка"];
        [specs addObject:g2];

        PSSpecifier *choose = [PSSpecifier preferenceSpecifierNamed:@"Выбрать из галереи"
                                                             target:self set:nil get:nil
                                                             detail:nil cell:PSButtonCell edit:nil];
        choose.buttonAction = @selector(chooseIcon);
        [specs addObject:choose];

        PSSpecifier *removeIcon = [PSSpecifier preferenceSpecifierNamed:@"Вернуть оригинальную иконку"
                                                                 target:self set:nil get:nil
                                                                 detail:nil cell:PSButtonCell edit:nil];
        removeIcon.buttonAction = @selector(removeIcon);
        [specs addObject:removeIcon];

        PSSpecifier *g3 = [PSSpecifier groupSpecifierWithName:nil];
        [g3 setProperty:@"Изменения вступят в силу после «Применить (Respring)» на предыдущем экране."
                 forKey:@"footerText"];
        [specs addObject:g3];

        PSSpecifier *reset = [PSSpecifier preferenceSpecifierNamed:@"Сбросить всё для этого приложения"
                                                            target:self set:nil get:nil
                                                            detail:nil cell:PSButtonCell edit:nil];
        reset.buttonAction = @selector(resetAll);
        [specs addObject:reset];

        _specifiers = specs;
    }
    return _specifiers;
}

#pragma mark - Config

- (NSMutableDictionary *)entry {
    NSDictionary *e = RILoadConfig()[[self bundleID]];
    return [e isKindOfClass:[NSDictionary class]] ? [e mutableCopy] : [NSMutableDictionary dictionary];
}

- (void)saveEntry:(NSDictionary *)entry {
    NSMutableDictionary *cfg = RILoadConfig();
    if (entry.count) cfg[[self bundleID]] = entry;
    else [cfg removeObjectForKey:[self bundleID]];
    RISaveConfig(cfg);
}

- (id)currentName:(PSSpecifier *)spec {
    return [self entry][@"name"];
}

- (void)setName:(id)value specifier:(PSSpecifier *)spec {
    NSString *s = [value isKindOfClass:[NSString class]]
        ? [(NSString *)value stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]
        : @"";
    NSMutableDictionary *e = [self entry];
    if (s.length) e[@"name"] = s; else [e removeObjectForKey:@"name"];
    [self saveEntry:e];
}

#pragma mark - Icon

- (void)chooseIcon {
    UIImagePickerController *p = [[UIImagePickerController alloc] init];
    p.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    p.delegate = self;
    [self presentViewController:p animated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker
didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey, id> *)info {
    UIImage *img = info[UIImagePickerControllerOriginalImage];
    [picker dismissViewControllerAnimated:YES completion:nil];
    if (!img) return;

    NSData *png = UIImagePNGRepresentation(RISquareIcon(img, 512));
    NSString *file = [[self bundleID] stringByAppendingPathExtension:@"png"];
    NSString *path = [RIBaseDir() stringByAppendingPathComponent:file];
    [[NSFileManager defaultManager] createDirectoryAtPath:RIBaseDir()
                              withIntermediateDirectories:YES attributes:nil error:nil];
    if ([png writeToFile:path atomically:YES]) {
        NSMutableDictionary *e = [self entry];
        e[@"icon"] = file;
        [self saveEntry:e];
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)removeIcon {
    NSMutableDictionary *e = [self entry];
    NSString *file = e[@"icon"];
    if (file.length) {
        [[NSFileManager defaultManager] removeItemAtPath:[RIBaseDir() stringByAppendingPathComponent:file] error:nil];
    }
    [e removeObjectForKey:@"icon"];
    [self saveEntry:e];
}

- (void)resetAll {
    [self removeIcon];
    NSMutableDictionary *e = [self entry];
    [e removeObjectForKey:@"name"];
    [self saveEntry:e];
    [self reloadSpecifiers];
}

@end
