#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <notify.h>
#import "RIAppController.h"
#import "RIConfig.h"

@interface LSApplicationProxy : NSObject
@property (nonatomic, readonly) NSString *applicationIdentifier;
@property (nonatomic, readonly) NSString *localizedName;
@property (nonatomic, readonly) NSString *applicationType;
@end

@interface LSApplicationWorkspace : NSObject
+ (instancetype)defaultWorkspace;
- (NSArray *)allInstalledApplications;
@end

@interface RIRootListController : PSListController
@end

@implementation RIRootListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        NSMutableArray *specs = [NSMutableArray array];
        self.title = @"Rename Icons";

        PSSpecifier *g1 = [PSSpecifier groupSpecifierWithName:nil];
        [g1 setProperty:@"Выбери приложение ниже, чтобы изменить его название или иконку. Потом нажми «Применить»."
                 forKey:@"footerText"];
        [specs addObject:g1];

        PSSpecifier *apply = [PSSpecifier preferenceSpecifierNamed:@"Применить (Respring)"
                                                            target:self set:nil get:nil
                                                            detail:nil cell:PSButtonCell edit:nil];
        apply.buttonAction = @selector(respring);
        [specs addObject:apply];

        [specs addObject:[PSSpecifier groupSpecifierWithName:@"Приложения"]];

        NSMutableArray *apps = [NSMutableArray array];
        NSMutableSet *seen = [NSMutableSet set];
        for (LSApplicationProxy *p in [[LSApplicationWorkspace defaultWorkspace] allInstalledApplications]) {
            NSString *bid = p.applicationIdentifier;
            NSString *name = p.localizedName;
            NSString *type = p.applicationType;
            if (!bid.length || !name.length || [seen containsObject:bid]) continue;
            if (![type isEqualToString:@"User"] && ![type isEqualToString:@"System"]) continue;
            if ([p respondsToSelector:@selector(appTags)]) {
                NSArray *tags = [p valueForKey:@"appTags"];
                if ([tags containsObject:@"hidden"]) continue;
            }
            [seen addObject:bid];
            [apps addObject:@{@"bid": bid, @"name": name}];
        }
        [apps sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
            return [a[@"name"] localizedCaseInsensitiveCompare:b[@"name"]];
        }];

        for (NSDictionary *app in apps) {
            PSSpecifier *s = [PSSpecifier preferenceSpecifierNamed:app[@"name"]
                                                            target:self
                                                               set:nil
                                                               get:@selector(customName:)
                                                            detail:[RIAppController class]
                                                              cell:PSLinkCell
                                                              edit:nil];
            [s setProperty:app[@"bid"] forKey:@"bundleID"];
            [specs addObject:s];
        }

        _specifiers = specs;
    }
    return _specifiers;
}

- (id)customName:(PSSpecifier *)spec {
    NSDictionary *e = RILoadConfig()[[spec propertyForKey:@"bundleID"]];
    return [e isKindOfClass:[NSDictionary class]] ? e[@"name"] : nil;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self reloadSpecifiers];
}

- (void)respring {
    notify_post("com.user.renameicons/respring");
}

@end
