#import "RIConfig.h"
#import <rootless.h>

NSString *RIBaseDir(void) {
    return ROOT_PATH_NS(@"/var/mobile/Library/RenameIcons");
}

static NSString *RIConfigPath(void) {
    return [RIBaseDir() stringByAppendingPathComponent:@"config.plist"];
}

NSMutableDictionary *RILoadConfig(void) {
    NSMutableDictionary *cfg = [NSMutableDictionary dictionaryWithContentsOfFile:RIConfigPath()];
    return cfg ?: [NSMutableDictionary dictionary];
}

BOOL RISaveConfig(NSDictionary *cfg) {
    [[NSFileManager defaultManager] createDirectoryAtPath:RIBaseDir()
                              withIntermediateDirectories:YES
                                               attributes:nil
                                                    error:nil];
    return [cfg writeToFile:RIConfigPath() atomically:YES];
}
